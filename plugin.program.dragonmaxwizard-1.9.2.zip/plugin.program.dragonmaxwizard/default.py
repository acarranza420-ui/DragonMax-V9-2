import xbmcgui, xbmcaddon
ADDON = xbmcaddon.Addon()
menu = [
    'Install DragonMax V9.2 Build Content',
    'Apply Netflix-Style Layout',
    'Apply AuraMOD Config Templates',
    'Open Dragon Portal Tools',
    'Performance Mode: Balanced / Visual Quality / Maximum Speed',
    'Repair / Recovery Center',
    'View GitHub Install Instructions'
]
idx = xbmcgui.Dialog().select('DragonMax Wizard', menu)
if idx >= 0:
    xbmcgui.Dialog().ok('DragonMax Wizard', 'Selected: ' + menu[idx], 'This clean package stages templates and assets. Apply settings through AuraMOD/skin shortcuts where supported.')
